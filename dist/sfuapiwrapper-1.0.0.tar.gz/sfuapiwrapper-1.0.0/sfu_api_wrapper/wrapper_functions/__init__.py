from .course_offering import course_offering
from .departments import departments
