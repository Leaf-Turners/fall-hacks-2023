async def course_offering(department: str, number: str, section: str, year: int = 'current', term: str = 'current'):
    print('course offering')
