async def departments(year: int = 'current', term: str = 'current'):
    print('departments')
