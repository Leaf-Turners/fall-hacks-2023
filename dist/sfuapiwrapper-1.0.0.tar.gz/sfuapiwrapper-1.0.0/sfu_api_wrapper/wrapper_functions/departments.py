from ..requests import CourseOutlinesAPI


async def departments(year: int = 'current', term: str = 'current'):
    data = await CourseOutlinesAPI.get_departments(year, term)
    return data
