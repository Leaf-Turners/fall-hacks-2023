from .course import CourseOutline
from .instructor import Instructor
from .schedule import CourseSchedule
